#Criação de numero aleatório

import random

def atividade1():
    n1 = random.randint(5,10)
    n2 = random.randint(5,10)
    n3 = random.randint(5,10)
    return (n1, n2, n3)

# print(atividade1())

import random
def atividade2():
    n1 = random.random()
    n2 = random.random()
    n3 = random.random()
    return (n1,n2,n3)

# print(atividade2())


def atividade3():
    n = random.randrange(10,30)
    return n

# print(atividade3())

def atividade4():
    for i in range(10, 0, -1):
        print(i)
atividade4()
print("fogo!")



