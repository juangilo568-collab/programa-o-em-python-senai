import modulo

print(modulo.atividade1())